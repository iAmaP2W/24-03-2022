package com.example.logindemo;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.Date;

public class WorkViewmodel extends ViewModel {
    private MutableLiveData<Date> startDate;
    private MutableLiveData<Date> endDate;
    private MutableLiveData<Date> diffDate;
    private MutableLiveData<Double> diff;
    private MutableLiveData<Boolean> isButtonEnabled;
    private MutableLiveData<String> userName;
    private MutableLiveData<String> userPassword;
    private MutableLiveData<Double> loon;

    public MutableLiveData<Date> getStartDate() {
        if (startDate == null) {
            startDate = new MutableLiveData<Date>();
        }
        return startDate;
    }

    public MutableLiveData<Date> getEndDate() {
        if (endDate == null) {
            endDate = new MutableLiveData<Date>();
        }
        return endDate;
    }

    public MutableLiveData<Date> getDiffDate() {
        if (diffDate == null) {
            diffDate = new MutableLiveData<Date>();
        }
        return diffDate;
    }

    public MutableLiveData<Double> getDiff() {
        if (diff == null) {
            diff = new MutableLiveData<Double>();
        }
        return diff;
    }

    public MutableLiveData<Boolean> getIsButtonEnabled() {
        if (isButtonEnabled == null) {
            isButtonEnabled = new MutableLiveData<Boolean>();
        }
        return isButtonEnabled;
    }

    public MutableLiveData<String> getUserName() {
        if (userName == null) {
            userName = new MutableLiveData<String>();
        }
        return userName;
    }

    public MutableLiveData<String> getUserPassword() {
        if (userPassword == null) {
            userPassword = new MutableLiveData<String>();
        }
        return userPassword;
    }
    public MutableLiveData<Double> getLoon() {
        if (loon == null) {
            loon = new MutableLiveData<Double>();
        }
        return loon;
    }

}
