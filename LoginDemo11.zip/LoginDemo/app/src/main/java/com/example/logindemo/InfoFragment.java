package com.example.logindemo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import java.io.IOException;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InfoFragment extends Fragment {
    TextView Name;
    TextView Password;
    TextView Loon;
    Button btnLogout;
    private WorkViewmodel viewmodel;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_info,container, false);
        viewmodel= ViewModelProviders.of(requireActivity()).get(WorkViewmodel.class);
        Name=view.findViewById(R.id.txtName);
        Password=view.findViewById(R.id.txtPassword);
        Loon=view.findViewById(R.id.txtLoon);
        btnLogout = view.findViewById(R.id.btn_logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getActivity(),MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                //getActivity().finish();// Wordt niet uitgevoerd omdat het start activity is!
            }
        });
        if(viewmodel.getLoon().getValue()!=null){
            Loon.setText(viewmodel.getLoon().getValue().toString());
        }
        TextWatcher loonWatcher=new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(!editable.toString().equals("")){
                    viewmodel.getLoon().setValue(Double.valueOf(editable.toString()));
                    Update(viewmodel.getUserName().getValue(),viewmodel.getUserPassword().getValue(),viewmodel.getLoon().getValue().toString());
                }
                else{
                    viewmodel.getLoon().setValue(Double.valueOf(0.00));
                }

            }
        };
        Loon.addTextChangedListener(loonWatcher);

        final Observer<String> userNameObserver= new Observer<String>() {
            @Override
            public void onChanged(String userName) {
                Name.setText(userName);
            }
        };
        viewmodel.getUserName().observe(requireActivity(),userNameObserver);
        final Observer<String> userPasswordObserver= new Observer<String>() {
            @Override
            public void onChanged(String userPassword) {
                Password.setText(userPassword.replaceAll(".","*"));
            }
        };
        viewmodel.getUserPassword().observe(requireActivity(),userPasswordObserver);
        return view;


        /*btnLogout = view.findViewById(R.id.btn_logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getActivity(),MainActivity.class);

            }
        });*/
    }
    private void Update(String userName, String userPassword,String loon){

        Call<Boolean> call = RetrofitClient.getInstance().getMyApi().loon(userName,userPassword,loon);
        call.enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if(response.isSuccessful()) {

                    Boolean myheroList = response.body();
                    Log.i("LoginDemo:succes",myheroList.toString());
                    Toast.makeText(getContext(),"Succesvol aangepast!", Toast.LENGTH_LONG).show();
                }
                else {

                    if(response.errorBody() != null) {
                        try {
                            Log.i("LoginDemo:", response.errorBody().string());

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                Log.i("LoginDemo:", t.toString());
            }

        });

    }
}
